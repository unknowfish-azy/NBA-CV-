# 数据上传清单与命名说明（手动上传版）

> 原则：只提交**小体积证据 / 清单 / 报告 / 语料**，不提交原始帧、视频、模型权重（约 68GB 原始数据留在本地，由 `local_file_manifest.csv` 引用）。
>
> **命名核对结论：本次 42 个文件全部为「新增」，且所有文件名已改为全局唯一（无任何重名 basename），不会顶替 GitHub 上任何已有文件。**

---

## 一、总览

- 新增：42 个文件，共约 4.75 MB
- 位于 4 个全新目录：`audit/`、`llm/`、`metadata/`、`model-meta/`
- `git status` 已核验：全部为新增（`A`），零修改（`M`）
- 全仓库重名扫描：我的新文件**无重名**（剩余重名均为仓库原本已有的 `runs/` 曲线图，与本次无关）

---

## 二、新增文件映射（来源 → 仓库）

### 1. `audit/runs/20261008-103426/` — 数据审计证据
| 仓库文件 | 本地来源 | 说明 |
|---|---|---|
| `split_audit.json` | `E:\NBA-Audit-Toolkit\runs\20261008-103426\` | **court 划分泄漏失败证据（gate=FAIL，14 组 train/valid 重叠、15 组 test 重叠、612 张来源未确认）** |
| `human_review.csv` | 同目录 | 600 张人工复核队列 |
| `player_sources.json` | 同目录 | 球员资料来源声明 |
| `repo_sources.json` | 同目录 | GitHub 固定 commit + 64 文件哈希 |
| `smoke_status.json` | 同目录 | 本地训练 smoke 实测 |
| `cloud_preflight.json` | 同目录 | AWS 只读预检状态 |

### 2. `llm/entry_layer/` — 大模型进入层语料（对话 + 结果答案）
| 仓库文件 | 说明 |
|---|---|
| `corpus.jsonl` / `corpus_meta.jsonl` | 训练语料 |
| `gold.jsonl` | 金标准答案 |
| `pred_v1.jsonl` / `pred_v2.jsonl` / `pred_v3.jsonl` | 模型预测结果 |
| `regression.jsonl` | 回归样本 |

### 3. `metadata/` — 场景标签 + 训练代码
| 仓库文件 | 说明 |
|---|---|
| `scene-labels/b1_v1_qwen_labels.jsonl`、`b1v2_qwen_labels.jsonl`、`b2_hero_review.jsonl` | Qwen3-VL 生成标签（未人工审核） |
| `scene-labels-b1c/gsw-hou-g7_labels.jsonl`、`guanlan-hou_labels.jsonl`、`lal-hou-recap_labels.jsonl`、`thunder-hou-recap_labels.jsonl`、`zchhf_labels.jsonl` | 分场次 Qwen 标签 |
| `code-b1/b1_label.py`、`b1_manifest.json`、`hero_variants.json` | 标注/清单脚本 |
| `code-court/train_court.py` | 球场训练脚本 |
| `code-pose/data_ref.yaml`、`train_pose.py` | 姿态训练脚本 |

### 4. `model-meta/` — 模型配置 / 结果（**不含权重，文件名已加前缀防重名**）
| 仓库文件 | 说明 |
|---|---|
| `court_v3/court_v3_args.yaml`、`court_v3/court_v3_metrics.json`、`court_v3/court_v3_results.csv` | court_v3 训练配置与指标 |
| `ball_foot_v1/ball_foot_v1_args.yaml`、`ball_foot_v1_data_snapshot.yaml`、`ball_foot_v1_manifest.json`、`ball_foot_v1_results.csv` | ball/foot 训练配置与指标 |
| `players_v25i_v1/players_v25i_v1_args.yaml`、`players_v25i_v1_data_snapshot.yaml`、`players_v25i_v1_manifest.json`、`players_v25i_v1_results.csv` | 球员检测配置与指标 |
| `omni_lora_v5/omni_lora_v5_adapter_config.json`、`omni_lora_v5_README.md` | Qwen Omni LoRA v5 配置 |
| `omni_lora_v7_commentary/omni_lora_v7_commentary_adapter_config.json`、`omni_lora_v7_commentary_train_summary.json` | 解说 LoRA v7（12089 行、eval delta -43.5%） |

---

## 三、重命名对照表（原名 → 新名，避免重名顶替）

| 原文件名 | 现文件名 | 原因 |
|---|---|---|
| `court_v3/results.csv` | `court_v3/court_v3_results.csv` | 3 个模型都有 `results.csv`，加前缀区分 |
| `ball_foot_v1/results.csv` | `ball_foot_v1/ball_foot_v1_results.csv` | 同上 |
| `players_v25i_v1/results.csv` | `players_v25i_v1/players_v25i_v1_results.csv` | 同上 |
| `court_v3/args.yaml` | `court_v3/court_v3_args.yaml` | 同上 |
| `ball_foot_v1/args.yaml` | `ball_foot_v1/ball_foot_v1_args.yaml` | 同上 |
| `players_v25i_v1/args.yaml` | `players_v25i_v1/players_v25i_v1_args.yaml` | 同上 |
| `ball_foot_v1/manifest.json` | `ball_foot_v1/ball_foot_v1_manifest.json` | 2 个模型都有 `manifest.json` |
| `players_v25i_v1/manifest.json` | `players_v25i_v1/players_v25i_v1_manifest.json` | 同上 |
| `ball_foot_v1/data_snapshot.yaml` | `ball_foot_v1/ball_foot_v1_data_snapshot.yaml` | 同上 |
| `players_v25i_v1/data_snapshot.yaml` | `players_v25i_v1/players_v25i_v1_data_snapshot.yaml` | 同上 |
| `omni_lora_v5/adapter_config.json` | `omni_lora_v5/omni_lora_v5_adapter_config.json` | 2 个 LoRA 都有 `adapter_config.json` |
| `omni_lora_v7_commentary/adapter_config.json` | `omni_lora_v7_commentary/omni_lora_v7_commentary_adapter_config.json` | 同上 |
| `omni_lora_v5/README.md` | `omni_lora_v5/omni_lora_v5_README.md` | **避免顶替仓库顶层 `README.md`** |

> 注：若日后要**复用**这些 LoRA 配置，需把 `omni_lora_v5_adapter_config.json` 改回 `adapter_config.json` 才能被 PEFT 识别（原文件名已在上表保留对照）。

---

## 四、与仓库已有文件的关系（未覆盖清单）

| 仓库已有文件 | 处理 |
|---|---|
| `README.md`（顶层） | 未覆盖；`omni_lora_v5_README.md` 是不同文件 |
| `manifest.csv`、`local_file_manifest.csv`、`local_data_summary.json` | 未覆盖（`local_file_manifest.csv` 已比对 SHA 完全一致） |
| `stage_status.json`、`handoff_manual.md`、`summary_court_v8s_seg.json`、`config.json`、`checks.json` | 未覆盖 |
| `runs/court_v8s_seg/*`、`runs/court_v8s_seg_val/*`、`best.pt` | 仓库原本已有的，未改动 |

---

## 五、刻意**未**上传（避免超限 / 污染）

| 文件 / 目录 | 大小 | 原因 |
|---|---|---|
| `dataset_manifest.json` | 124 MB | 超 GitHub 100MB 单文件上限 |
| `annotation_audit.json` | 45.8 MB | 审计中间产物，体积大 |
| `b1_frames.zip` | 306 MB | 超上限 |
| 所有 `.pt` / `.safetensors` 权重 | GB 级 | 权重不进 Git（已加 `.gitignore`） |
| `data/`（原始帧 + 标注） | 55.7 GB | 原始数据留本地 |
| 视频 / 抽帧 / 媒体 | 数十 GB | 不进 Git |

---

## 六、手动上传步骤（GitHub 网页端）

1. 打开仓库 `unknowfish-azy/NBA-CV-dataChanges`，点 **Add file → Upload files**。
2. 对每个目录，先进入对应路径再上传（保持目录结构）：
   - `audit/runs/20261008-103426/` ← 上传 audit 的 6 个文件
   - `llm/entry_layer/` ← 上传 llm 的 7 个文件
   - `metadata/scene-labels/`、`metadata/scene-labels-b1c/`、`metadata/code-b1/`、`metadata/code-court/`、`metadata/code-pose/` ← 上传 metadata 的 14 个文件
   - `model-meta/court_v3/`、`model-meta/ball_foot_v1/`、`model-meta/players_v25i_v1/`、`model-meta/omni_lora_v5/`、`model-meta/omni_lora_v7_commentary/` ← 上传 model-meta 的 15 个文件
3. `.gitignore` 和 `DATA_UPLOAD_MANIFEST.md` 传到仓库**根目录**。
4. 由于所有文件名已全局唯一，即使误传到根目录也不会覆盖已有文件（但建议还是按目录结构传，保持整洁）。

> 更省事的办法：直接 `git clone` 仓库 → 把本清单对应的 4 个目录 + 2 个根文件复制进去 → `git add -A && git commit && git push`（用你有写权限的账号）。

---

*生成方式：从本地 `E:\` 逐文件复制（`Copy-Item` 字节级保留）→ 重名文件加前缀改为全局唯一 → `git status` 核验全新增、零修改、零重名。*
