# -*- coding: utf-8 -*-
"""B1 帧批量标注(Qwen3-VL-235B) + B2 hero 变体复核(Claude Sonnet 4.6)。

输入: /opt/ml/input/data/code/{b1_frames.zip, b1_manifest.json, hero_variants.json}
输出: /opt/ml/output/data/{b1_qwen_labels.jsonl, b2_hero_review.jsonl, b1_summary.json}

纪律: 7 键 schema 对齐项目 vlm_scene_tag.py;不确定=unknown 禁编造;
失败帧记 err 继续不恋战;容器内只有 boto3(无 aws cli)。
"""
import base64
import json
import os
import threading
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import boto3

QWEN_MODEL = "qwen.qwen3-vl-235b-a22b"
SONNET_MODEL = "global.anthropic.claude-sonnet-4-6"
WORKERS = int(os.environ.get("B1_WORKERS", "6"))

ROSTER_HINT = """两队球员名单(2025-26 赛季,用于识别画面球员与纠正音译):
休斯顿火箭: 杰伦·格林 阿尔佩伦·申京 凯文·杜兰特(若在场) 贾巴里·史密斯 阿门·汤普森 范弗里特 里德 谢泼德
达拉斯独行侠: 卢卡·东契奇(若已转会则忽略) 凯里·欧文 安东尼·戴维斯 克莱·汤普森 德里克·莱夫利 科比·怀特
球衣颜色参考: 火箭主场白/红,独行侠蓝/白;以画面实际为准。"""

SCENE_PROMPT = f"""你是 NBA 比赛画面分析专家,负责为解说 AI 训练数据标注画面内容。{ROSTER_HINT}

对这一帧,按状态追踪范式回答(不确定就标 unknown,禁止编造):
1. shot_type: 转播镜头类型(closeup特写/follow跟拍/wide全景/replay回放/bench替补席/scoreboard记分牌/other)
2. court_zone: 画面主体球场区域(三分线外左/右/顶弧、禁区、中距离、后场,或 off-court 不在球场)
3. action: 正在发生的动作(如 持球突破/三分出手/篮下卡位/防守轮转/暂停/罚球/犯规判罚/回放高光)
4. offense: 进攻方球衣颜色特征或队伍判断(unknown 允许)
5. players_hint: 可辨识的球员(号码+位置特征),没有则 unknown
6. excitement: 画面激烈程度 1-5(5=对抗高潮/扣篮/绝杀类)
7. scoreboard: 若画面含记分牌,读出比分与剩余时间;否则 unknown

只输出一个 JSON 对象,七个键: shot_type, court_zone, action, offense, players_hint, excitement, scoreboard。值全为短中文短语。"""

HERO_REVIEW_PROMPT = """你是解说文案合规审查器。审查下面这条 NBA 解说 Hero 短语文本,只查三类违规:
1) 数字违规: 文本中出现任何具体数字/比分/时间(花括号槽位如 {target_slot} 是占位符不算数字);
2) 禁用词: 出现"概率"、"本来会进"、"官方Gravity"、"calibrated"、"确定性是"等冒充官方指标或 calibrated probability 的表述;
3) 越权表述: 声称知道官方未公开数据或冒名官方指标。

只输出一个 JSON 对象: {"verdict": "ok" 或 "violation", "issues": ["简短原因", ...]}。文本如下:
"""


def bedrock_with_retry(br, payload_fn, max_retry=5, base_wait=6):
    """Throttling/5xx 指数退避重试。"""
    last = None
    for k in range(max_retry):
        try:
            return payload_fn(br)
        except Exception as e:  # ThrottlingException / ServiceUnavailable / SSLEOF
            last = e
            wait = base_wait * (2 ** k)
            print(f"[retry {k}] {type(e).__name__}: {str(e)[:160]} -> sleep {wait}", flush=True)
            time.sleep(wait)
    raise last


def label_one(br, frame_dir, item):
    key = item["key"]
    fpath = frame_dir / key
    rec = {"key": key, "group": item.get("group"), "src": item.get("src")}
    try:
        raw = fpath.read_bytes()
        fmt = "png" if key.lower().endswith(".png") else "jpeg"
        if key.lower().endswith((".jpg", ".jpeg")):
            fmt = "jpeg"

        def call(c):
            return c.converse(
                modelId=QWEN_MODEL,
                messages=[{"role": "user", "content": [
                    {"image": {"format": fmt, "source": {"bytes": raw}}},
                    {"text": SCENE_PROMPT}]}],
                inferenceConfig={"maxTokens": 800, "temperature": 0.1})

        r = bedrock_with_retry(br, call)
        txt = ""
        for blk in r["output"]["message"]["content"]:
            if blk.get("text"):
                txt += blk["text"]
        txt = txt.strip()
        if txt.startswith("```"):
            txt = txt.split("```")[1]
            if txt.startswith("json"):
                txt = txt[4:]
            txt = txt.strip()
        labels = json.loads(txt)
        if not isinstance(labels, dict):
            raise ValueError(f"label not dict: {str(labels)[:120]}")
        rec["labels"] = labels
        rec["usage"] = {k2: v for k2, v in (r.get("usage") or {}).items()
                        if k2 in ("inputTokens", "outputTokens")}
    except Exception as e:
        rec["err"] = f"{type(e).__name__}: {str(e)[:300]}"
    return rec


def main():
    code_dir = Path("/opt/ml/input/data/code")
    out_dir = Path("/opt/ml/output/data")
    out_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(code_dir / "b1_frames.zip") as z:
        z.extractall("/tmp/b1")
    frame_root = Path("/tmp/b1")
    manifest = json.loads((code_dir / "b1_manifest.json").read_text(encoding="utf-8"))
    frames = manifest["frames"]
    print(f"B1 frames={len(frames)}", flush=True)

    br = boto3.client("bedrock-runtime", region_name="us-east-1",
                      config=boto3.session.Config(
                          retries={"max_attempts": 3, "mode": "standard"},
                          read_timeout=120, connect_timeout=10))

    out_path = out_dir / "b1_qwen_labels.jsonl"
    lock = threading.Lock()
    done, failed = 0, 0
    t0 = time.time()

    with open(out_path, "w", encoding="utf-8") as fout:
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            futs = {ex.submit(label_one, br, frame_root, it): it for it in frames}
            for fut in as_completed(futs):
                rec = fut.result()
                with lock:
                    fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    if (done + 1) % 50 == 0:
                        fout.flush()
                    done += 1
                    if rec.get("err"):
                        failed += 1
                    if done % 100 == 0:
                        el = time.time() - t0
                        print(f"[B1] done={done}/{len(frames)} failed={failed} "
                              f"elapsed={el:.0f}s rate={done/el*60:.0f}/min", flush=True)

    # ---- B2: hero 变体 Sonnet 复核(抽 20 条:每个 verdict 前 5 条) ----
    hv = json.loads((code_dir / "hero_variants.json").read_text(encoding="utf-8"))
    by_verdict = {}
    for v in hv["variants"]:
        by_verdict.setdefault(v["verdict"], []).append(v)
    picked = []
    for verdict in sorted(by_verdict):
        picked.extend(by_verdict[verdict][:5])
    picked = picked[:20]

    b2_path = out_dir / "b2_hero_review.jsonl"
    b2_ok = b2_violation = 0
    with open(b2_path, "w", encoding="utf-8") as f2:
        for v in picked:
            rec = {"verdict": v["verdict"], "idx": v["idx"], "text": v["text"]}
            try:
                def call(c):
                    return c.converse(
                        modelId=SONNET_MODEL,
                        messages=[{"role": "user", "content": [
                            {"text": HERO_REVIEW_PROMPT + v["text"]}]}],
                        inferenceConfig={"maxTokens": 400, "temperature": 0.0})

                r = bedrock_with_retry(br, call)
                txt = "".join(b.get("text", "") for b in r["output"]["message"]["content"]).strip()
                if txt.startswith("```"):
                    txt = txt.split("```")[1]
                    if txt.startswith("json"):
                        txt = txt[4:]
                    txt = txt.strip()
                j = json.loads(txt)
                rec["review"] = j
                if j.get("verdict") == "ok":
                    b2_ok += 1
                else:
                    b2_violation += 1
            except Exception as e:
                rec["err"] = f"{type(e).__name__}: {str(e)[:300]}"
            f2.write(json.dumps(rec, ensure_ascii=False) + "\n")
            f2.flush()

    summary = {
        "b1_frames_total": len(frames),
        "b1_labeled_ok": done - failed,
        "b1_failed": failed,
        "b1_wall_s": round(time.time() - t0, 1),
        "b1_rate_per_min": round(done / max(time.time() - t0, 1) * 60, 1),
        "b2_variants_picked": len(picked),
        "b2_ok": b2_ok, "b2_violation": b2_violation,
    }
    (out_dir / "b1_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
    print("SUMMARY", json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
