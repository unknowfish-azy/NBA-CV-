#!/usr/bin/env python3
"""pose_subcoco 姿态训练容器入口(ultralytics;MODEL_SIZE 由环境变量注入)"""
import json, os, shutil, subprocess
from pathlib import Path
MODEL_SIZE = os.environ.get("MODEL_SIZE", "n")   # n | s
DS = "/opt/ml/input/data/dataset"
out = Path("/opt/ml/output/data"); out.mkdir(parents=True, exist_ok=True)
# data.yaml 需指向容器内挂载点
yaml_txt = f"path: {DS}\ntrain: images/train\nval: images/val\nnc: 1\nnames: [person]\nkpt_shape: [17, 3]\n"
yaml_p = Path("/tmp/pose_subcoco.yaml"); yaml_p.write_text(yaml_txt, encoding="utf-8")
subprocess.run(["pip", "install", "-q", "ultralytics"], check=False)
from ultralytics import YOLO
base = f"yolo11{MODEL_SIZE}-pose.pt"
if not Path(base).exists():
    # S3 上有 n 版;s 版让 ultralytics 自动下载
    try:
        subprocess.run(["aws", "s3", "cp", "s3://nba-hackathon-766815611718-team41/awsbatch/model/yolo11n-pose.pt", ".", "--region", "us-east-1"], check=False)
    except Exception: pass
    if MODEL_SIZE == "s" and not Path(base).exists():
        subprocess.run(["pip", "install", "-q", "boto3"], check=False)  # 已有
model = YOLO(base if Path(base).exists() else f"yolo11{MODEL_SIZE}-pose.pt")
r = model.train(data=str(yaml_p), imgsz=640, epochs=40, batch=32 if MODEL_SIZE=="n" else 24,
                seed=0, project=str(out), name=f"pose_subcoco_{MODEL_SIZE}")
metrics = {}
try:
    metrics = {k: r.results_dict.get(k) for k in list(r.results_dict)[:10]}
except Exception: pass
(out/"final_metrics.json").write_text(json.dumps({"model": base, "metrics": metrics}, indent=1))
print(json.dumps(metrics, indent=1))
