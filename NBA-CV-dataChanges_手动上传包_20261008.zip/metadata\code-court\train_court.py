# -*- coding: utf-8 -*-
"""球场分割模型训练(SageMaker 容器内入口)。

输入: /opt/ml/input/data/data/dataset_v4(或通道根即 dataset_v4)
      结构: images/{train,val}/*.jpg + labels/{train,val}/*.txt(YOLO-seg 多边形)
输出: /opt/ml/output/data/ -> best.pt / last.pt / results.csv / args.yaml / meta_train.json

环境变量: EPOCHS(100), IMGSZ(640), BATCH(16), PATIENCE(30),
          MODEL(yolo11n-seg.pt,容器内联网自动下载)
"""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path


def pip_install():
    """锁 ultralytics 8.3.x(与 g1_perceive 同一版本纪律)。"""
    r = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet",
                        "ultralytics>=8.3.63,<8.4"],
                       capture_output=True, text=True)
    print(r.stdout[-2000:] if r.stdout else "", flush=True)
    if r.returncode != 0:
        print("PIP_STDERR:", r.stderr[-3000:], flush=True)
        raise SystemExit(f"pip install failed rc={r.returncode}")


def last_metrics(results_csv):
    """从 results.csv 最后一行提取主要指标列名->值。"""
    try:
        lines = results_csv.read_text(encoding="utf-8").strip().splitlines()
        if len(lines) < 2:
            return {}
        head = [h.strip().strip("/") for h in lines[0].split(",")]
        vals = [v.strip() for v in lines[-1].split(",")]
        keep = {}
        for k, v in zip(head, vals):
            if any(t in k for t in ("mAP50", "mAP", "precision", "recall", "loss")):
                try:
                    keep[k] = float(v)
                except ValueError:
                    pass
        return keep
    except Exception as e:
        return {"parse_error": str(e)}


def main():
    epochs = int(os.environ.get("EPOCHS", "100"))
    imgsz = int(os.environ.get("IMGSZ", "640"))
    batch = int(os.environ.get("BATCH", "16"))
    patience = int(os.environ.get("PATIENCE", "30"))
    base_model = os.environ.get("MODEL", "yolo11n-seg.pt")

    ddir = Path("/opt/ml/input/data/data/dataset_v4")
    if not (ddir / "images").exists():
        cand = Path("/opt/ml/input/data/data")
        if (cand / "images").exists():
            ddir = cand
    if not (ddir / "images/train").exists():
        raise SystemExit(f"dataset not found under {ddir}: "
                         f"{[p.name for p in ddir.rglob('*')][:20]}")

    # 容器内重建 yaml(S3 上那份是队友本地绝对路径,不可直接用)
    yaml_path = ddir / "court_v4_aws.yaml"
    yaml_path.write_text(
        f"path: {ddir.as_posix()}\ntrain: images/train\nval: images/val\n"
        "names:\n  0: basketball_court\n", encoding="utf-8")

    n_train = len(list((ddir / "images/train").glob("*.jpg")))
    n_val = len(list((ddir / "images/val").glob("*.jpg")))
    print(f"dataset: train={n_train} val={n_val} yaml={yaml_path}", flush=True)

    pip_install()
    import torch  # noqa: E402
    import ultralytics  # noqa: E402
    from ultralytics import YOLO  # noqa: E402
    print("ultralytics", ultralytics.__version__,
          "torch", torch.__version__, "cuda", torch.cuda.is_available(), flush=True)

    out_dir = Path("/opt/ml/output/data")
    out_dir.mkdir(parents=True, exist_ok=True)
    wall0 = time.time()

    model = YOLO(base_model)
    model.train(data=yaml_path.as_posix(), epochs=epochs, imgsz=imgsz, batch=batch,
                patience=patience, device=0, project=str(out_dir / "train"),
                name="court_v4", exist_ok=True, verbose=True, workers=8)

    run_dir = out_dir / "train" / "court_v4"
    for name in ("weights/best.pt", "weights/last.pt", "results.csv", "args.yaml"):
        src = run_dir / name
        if src.exists():
            shutil.copy2(src, out_dir / src.name)

    wall = time.time() - wall0
    meta = {
        "task": "court_segmentation_train",
        "dataset": {"train": n_train, "val": n_val, "classes": ["basketball_court"]},
        "base_model": base_model, "epochs": epochs, "imgsz": imgsz,
        "batch": batch, "patience": patience,
        "ultralytics_ver": ultralytics.__version__,
        "torch": torch.__version__, "cuda": torch.cuda.is_available(),
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "wall_s": round(wall, 1),
        "metrics": last_metrics(out_dir / "results.csv"),
        "schema": "best.pt -> g1_perceive 兼容(court 单类 seg)",
    }
    (out_dir / "meta_train.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    print("META", json.dumps(meta, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
